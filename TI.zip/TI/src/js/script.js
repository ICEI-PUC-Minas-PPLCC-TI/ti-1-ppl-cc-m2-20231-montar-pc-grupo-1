document.addEventListener('DOMContentLoaded', function () {
  const searchInput = document.getElementById('searchInput');
  const productList = document.getElementById('productList');

  searchInput.addEventListener('input', function () {
      const searchQuery = searchInput.value.toLowerCase();
      const products = Array.from(productList.getElementsByClassName('card-title'));

      products.forEach(function (product) {
          const productName = product.innerText.toLowerCase();
          const productCard = product.closest('.col-12');

          if (productName.includes(searchQuery)) {
              productCard.style.display = 'block';
          } else {
              productCard.style.display = 'none';
          }
      });
  });
});